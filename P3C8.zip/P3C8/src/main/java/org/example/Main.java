package org.example;
import java.io.*;
import java.util.*;
import org.listas.Lista;
import org.reproductor.Cancion;
import org.reproductor.ListaCancion;
import org.reproductor.ListaCancionOrdenada;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        String ruta="C:\\Users\\regaz\\OneDrive\\Escritorio\\canciones";
        ArrayList<String> lista= new ArrayList<>();
        File carp= new File(ruta);
        File[] archi= carp.listFiles();
        for (File archis : archi ){
            if(archis.isFile()){
                lista.add(archis.getName());
            }
        }

        Queue<String> archiacola= new LinkedList<>();
        for(String nombre: lista){
            archiacola.add(nombre);
        }

        System.out.println("Lista de canciones:  ");
        for(String nombre : lista){
            System.out.println(nombre);
        }

        System.out.println("\nCola de archivos:  ");
        while(!archiacola.isEmpty()){
            System.out.println(archiacola.poll());
        }

    }
}